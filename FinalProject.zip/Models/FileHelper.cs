﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace FinalProject.Models
{
    class FileHelper
    {
        public static string Read(string filePath)
        {
            if (File.Exists(filePath))
            {
                using (StreamReader reader = new StreamReader(filePath))
                {
                    return reader.ReadToEnd();
                }
            }
            return String.Empty;
        }

    }
}
